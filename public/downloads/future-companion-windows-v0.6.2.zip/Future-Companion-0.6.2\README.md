# Future Companion 0.6.2

Future Companion 是 Future / Melo 的本机网易云音乐桥。它只监听 `127.0.0.1`，通过官方 `@music163/ncm-cli` 控制这台电脑上的 mpv。

Future Companion is the local NetEase Cloud Music bridge for Future / Melo. It listens only on `127.0.0.1` and controls mpv through the official `@music163/ncm-cli` package.

## 中文安装指南

### 需要准备

- Windows 10/11
- [Node.js 18 或更新版本](https://nodejs.org/en/download)
- [mpv 播放器](https://mpv.io/installation/)
- 网易云音乐账号
- 按 [`@music163/ncm-cli` 官方说明](https://www.npmjs.com/package/@music163/ncm-cli)获取网易云音乐开放平台 App ID 与 Private Key

### 首次使用

1. 解压整个 ZIP，不要直接在压缩包预览窗口里运行文件。
2. 双击 `setup-companion.cmd`。脚本会检查 Node.js 与 mpv，并安装固定版本的官方网易云 CLI。
3. 按终端提示填写 App ID 与 Private Key，再使用网易云音乐 App 扫码登录。
4. 双击 `start-companion.cmd`，保持这个终端窗口开启。
5. 复制终端中的“本机配对码”。在 Future 网站进入 `Melo → 设置 → 网易云桌面桥`，保持默认地址 `http://127.0.0.1:45731`，粘贴配对码并点“测试本机桥”。

如果网易云登录过期，关闭正在运行的 Companion，双击 `login-companion.cmd` 重新扫码，再启动 `start-companion.cmd`。

Windows 可能对尚未积累信誉的 ZIP 或脚本显示 SmartScreen 提示。请确认文件来自 Future 官方网站；需要继续时选择“更多信息 → 仍要运行”。

## English setup guide

### Requirements

- Windows 10/11
- [Node.js 18 or later](https://nodejs.org/en/download)
- [mpv](https://mpv.io/installation/)
- A NetEase Cloud Music account
- A NetEase Open Platform App ID and Private Key, following the [official `@music163/ncm-cli` instructions](https://www.npmjs.com/package/@music163/ncm-cli)

### First run

1. Extract the entire ZIP. Do not run the scripts from inside the ZIP preview.
2. Double-click `setup-companion.cmd`. It checks Node.js and mpv, then installs the pinned official NetEase CLI package.
3. Enter the App ID and Private Key when prompted, then scan the QR code with the NetEase Cloud Music app.
4. Double-click `start-companion.cmd` and keep the terminal window open.
5. Copy the local pairing code. In Future, open `Melo → Settings → NetEase desktop companion`, keep `http://127.0.0.1:45731`, paste the code, and choose “Test companion.”

If the NetEase session expires, close the running companion, double-click `login-companion.cmd`, scan the QR code again, and restart `start-companion.cmd`.

Windows SmartScreen may warn about a ZIP or script that has not built download reputation yet. Confirm that it came from the official Future website; if you want to continue, choose “More info → Run anyway.”

## Privacy and security

- NetEase cookies, App Private Key, sign-in state, and audio stay on this computer. They are not uploaded to Future, Cloudflare, Supabase, or DeepSeek.
- The local server binds only to `127.0.0.1`. It does not accept arbitrary terminal commands; only the playback actions listed below are allowed.
- The pairing code is created on first launch in `.future-companion/config.json`. Do not share it. The website keeps its copy only in the current browser tab.
- Only when you explicitly choose “Analyze & save with DS” are selected track and artist names sent through Future to your own DeepSeek API for a taste profile. Audio, playlist IDs, playback URLs, cookies, and sign-in credentials are not sent.

## Allowlisted actions

- Daily recommendations and exact song/artist search
- A Melo-generated local queue of up to five playable matches
- Pause, resume, stop, previous, next, seek, volume, and mute
- Current track, playback status, and progress synchronization
- Read-only playlist listing and selected track/artist metadata for taste analysis

## Advanced options

- `FUTURE_COMPANION_PORT`: local port, default `45731`
- `FUTURE_COMPANION_TOKEN`: custom pairing code of at least 24 characters
- `FUTURE_COMPANION_ORIGINS`: comma-separated additional allowed website origins
- `NCM_CLI_ENTRY`: explicit `ncm-cli` JavaScript entry when global discovery fails

Run the source checks with `npm test`.
