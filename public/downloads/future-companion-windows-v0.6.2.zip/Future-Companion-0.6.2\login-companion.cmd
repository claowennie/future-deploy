@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Future Companion - NetEase Login

where node.exe >nul 2>nul
if errorlevel 1 goto node_missing

echo Scan the QR code with the NetEase Cloud Music app.
echo.
node "src\setup.mjs" login
if errorlevel 1 goto login_failed

echo.
node "src\setup.mjs" check
if errorlevel 1 goto verify_failed

echo Login complete.
echo Restart Future Companion if it is already open.
pause
exit /b 0

:node_missing
echo Node.js was not found.
echo Run setup-companion.cmd first.
goto failed

:login_failed
echo.
echo Login was not completed.
goto failed

:verify_failed
echo.
echo Login verification failed.
goto failed

:failed
pause
exit /b 1
