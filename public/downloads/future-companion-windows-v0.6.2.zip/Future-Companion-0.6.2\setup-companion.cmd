@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Future Companion Setup

echo ============================================================
echo Future Companion first-time setup
echo ============================================================
echo.

where node.exe >nul 2>nul
if errorlevel 1 goto node_missing

for /f %%V in ('node -p "process.versions.node.split(`.`)[0]"') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR goto node_missing
if %NODE_MAJOR% LSS 18 goto node_old

where npm.cmd >nul 2>nul
if errorlevel 1 goto npm_missing

echo [1/4] Installing the pinned NetEase ncm-cli component...
call npm.cmd install --global @music163/ncm-cli@0.1.6
if errorlevel 1 goto install_failed

if exist "C:\Program Files\MPV Player\mpv.exe" set "PATH=C:\Program Files\MPV Player;%PATH%"
where mpv.exe >nul 2>nul
if errorlevel 1 goto mpv_missing

echo.
echo [2/4] Configure NetEase Open Platform credentials.
echo Setup reference: https://www.npmjs.com/package/@music163/ncm-cli
echo.
node "src\setup.mjs" configure
if errorlevel 1 goto configure_failed

echo.
echo [3/4] Sign in to NetEase Cloud Music with the QR code.
echo.
node "src\setup.mjs" login
if errorlevel 1 goto login_failed

echo.
echo [4/4] Verifying sign-in...
node "src\setup.mjs" check
if errorlevel 1 goto login_failed

echo.
echo ============================================================
echo Setup complete
echo Now run start-companion.cmd and copy the pairing code into:
echo Future website ^> Melo ^> Settings ^> NetEase desktop companion
echo Keep the companion window open while Melo is playing music.
echo ============================================================
echo.
pause
exit /b 0

:node_missing
echo Node.js was not found.
echo Install Node.js 18 or later: https://nodejs.org/en/download
goto failed

:node_old
echo Node.js %NODE_MAJOR% is too old.
echo Install Node.js 18 or later: https://nodejs.org/en/download
goto failed

:npm_missing
echo npm was not found.
echo Reinstall Node.js with npm enabled.
goto failed

:install_failed
echo Could not install @music163/ncm-cli.
echo Check the network and try again.
goto failed

:mpv_missing
echo mpv was not found.
echo Install mpv, then run this setup again: https://mpv.io/installation/
start "" "https://mpv.io/installation/"
goto failed

:configure_failed
echo NetEase Open Platform configuration was not completed.
echo Check the App ID and Private Key, then try again.
goto failed

:login_failed
echo NetEase sign-in was not completed.
echo Run this setup again when ready.
goto failed

:failed
echo.
pause
exit /b 1
