@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Future Companion

where node.exe >nul 2>nul
if errorlevel 1 goto node_missing

if exist "C:\Program Files\MPV Player\mpv.exe" set "PATH=C:\Program Files\MPV Player;%PATH%"

node "src\setup.mjs" locate >nul 2>nul
if errorlevel 1 goto not_setup

echo Starting Future Companion...
node "src\server.mjs"
set "EXIT_CODE=%errorlevel%"
echo.
if "%EXIT_CODE%"=="0" (
  echo Future Companion stopped.
) else (
  echo Future Companion exited with code %EXIT_CODE%.
)
echo Press any key to close.
pause >nul
exit /b %EXIT_CODE%

:node_missing
echo [Future Companion] Node.js was not found.
echo Install Node.js 18 or later, then run this file again:
echo https://nodejs.org/en/download
echo.
pause
exit /b 1

:not_setup
echo [Future Companion] The NetEase music component is not installed yet.
echo Run setup-companion.cmd once before starting the companion.
echo.
pause
exit /b 1
